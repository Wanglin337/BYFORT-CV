import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { CVFormData, cvFormSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Download, Printer, Rocket, Briefcase, FileText } from "lucide-react";

export default function Home() {
  const [cvPreview, setCvPreview] = useState<string>("");
  const [selectedFormat, setSelectedFormat] = useState<string>("preview");
  const { toast } = useToast();

  const form = useForm<CVFormData>({
    resolver: zodResolver(cvFormSchema),
    defaultValues: {
      nama: "",
      tgl_lahir: "",
      usia: 25,
      jk: undefined,
      email: "",
      telepon: "",
      alamat: "",
      pendidikan: "",
      keahlian: "",
      pengalaman: "",
    },
  });

  // Auto-calculate age from birth date
  const watchTglLahir = form.watch("tgl_lahir");
  
  useEffect(() => {
    if (watchTglLahir) {
      const birthDate = new Date(watchTglLahir);
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      
      if (age >= 0 && age <= 150) {
        form.setValue("usia", age);
      }
    }
  }, [watchTglLahir, form]);

  const downloadMutation = useMutation({
    mutationFn: async (data: { format: string; data: CVFormData; content: string }) => {
      const response = await apiRequest("POST", "/api/cv/download", data);
      return response;
    },
    onSuccess: (response, variables) => {
      if (variables.format !== "preview") {
        // Trigger download
        response.blob().then(blob => {
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = `CV-${variables.data.nama?.replace(/\s+/g, "-") || "BYFORT"}.${variables.format}`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        });
        
        toast({
          title: "CV berhasil didownload!",
          description: `File CV dalam format ${variables.format.toUpperCase()} telah didownload.`,
        });
      }
    },
    onError: () => {
      toast({
        title: "Gagal download CV",
        description: "Terjadi kesalahan saat mendownload CV. Silakan coba lagi.",
        variant: "destructive",
      });
    },
  });

  const generateCVContent = (data: CVFormData): string => {
    const currentDate = new Date().toLocaleDateString('id-ID');
    
    return `
      <div class="max-w-4xl mx-auto bg-white" id="cvDocument">
        <div class="text-center border-b-2 border-gray-200 pb-6 mb-6">
          <h1 class="text-3xl font-bold text-gray-800 mb-2">${data.nama}</h1>
          <div class="flex flex-wrap justify-center gap-4 text-gray-600 text-sm">
            ${data.email ? `<span>📧 ${data.email}</span>` : ''}
            ${data.telepon ? `<span>📱 ${data.telepon}</span>` : ''}
            <span>🎂 ${data.tgl_lahir} (${data.usia} tahun)</span>
            <span>👤 ${data.jk}</span>
          </div>
          ${data.alamat ? `<p class="text-gray-600 mt-2">📍 ${data.alamat}</p>` : ''}
        </div>
        
        ${data.pendidikan ? `
        <div class="mb-6">
          <h2 class="text-xl font-semibold text-gray-800 mb-3 border-l-4 border-blue-500 pl-3">🎓 PENDIDIKAN</h2>
          <p class="text-gray-700">${data.pendidikan}</p>
        </div>
        ` : ''}
        
        <div class="mb-6">
          <h2 class="text-xl font-semibold text-gray-800 mb-3 border-l-4 border-blue-500 pl-3">🚀 KEAHLIAN & KOMPETENSI</h2>
          <div class="text-gray-700 whitespace-pre-line">${data.keahlian}</div>
        </div>
        
        ${data.pengalaman ? `
        <div class="mb-6">
          <h2 class="text-xl font-semibold text-gray-800 mb-3 border-l-4 border-blue-500 pl-3">💼 PENGALAMAN KERJA</h2>
          <div class="text-gray-700 whitespace-pre-line">${data.pengalaman}</div>
        </div>
        ` : ''}
        
        <div class="text-center text-sm text-gray-500 border-t pt-4 mt-8">
          <p>CV dibuat menggunakan BYFORT CV Builder pada ${currentDate}</p>
        </div>
      </div>
    `;
  };

  const onSubmit = (data: CVFormData) => {
    const cvContent = generateCVContent(data);
    setCvPreview(cvContent);

    if (selectedFormat !== "preview") {
      downloadMutation.mutate({
        format: selectedFormat,
        data,
        content: cvContent,
      });
    }

    // Scroll to preview
    setTimeout(() => {
      document.getElementById("cvResult")?.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'start' 
      });
    }, 100);
  };

  const handleDownload = () => {
    if (!cvPreview) return;
    
    if (selectedFormat === "preview") {
      toast({
        title: "Pilih format file",
        description: "Silakan pilih format file untuk mendownload CV Anda.",
        variant: "destructive",
      });
      return;
    }

    const formData = form.getValues();
    downloadMutation.mutate({
      format: selectedFormat,
      data: formData,
      content: cvPreview,
    });
  };

  const handlePrint = () => {
    if (!cvPreview) return;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>CV Print</title>
            <style>
              body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 20px; }
              .border-l-4 { border-left: 4px solid #3B82F6; }
              .pl-3 { padding-left: 12px; }
              .mb-3 { margin-bottom: 12px; }
              .mb-6 { margin-bottom: 24px; }
              .text-3xl { font-size: 1.875rem; }
              .text-xl { font-size: 1.25rem; }
              .font-bold { font-weight: bold; }
              .font-semibold { font-weight: 600; }
              .text-center { text-align: center; }
              .border-b-2 { border-bottom: 2px solid #e5e7eb; }
              .pb-6 { padding-bottom: 24px; }
              .pt-4 { padding-top: 16px; }
              .mt-8 { margin-top: 32px; }
              .whitespace-pre-line { white-space: pre-line; }
            </style>
          </head>
          <body>${cvPreview}</body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  // Pop Under Ad Script
  useEffect(() => {
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = '//pl27311184.profitableratecpm.com/20/0a/d2/200ad28cee2adcd4b10f6bd0bb3f17be.js';
    document.head.appendChild(script);

    return () => {
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, []);

  return (
    <div className="font-inter bg-gray-50 min-h-screen">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-4xl font-bold mb-2">BYFORT</h1>
          <p className="text-xl text-gray-300">Pembuat CV Otomatis Professional</p>
          <p className="text-gray-400 mt-2">Buat CV kerja secara instan, cepat, dan gratis!</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* CV Form */}
          <Card className="bg-white rounded-xl shadow-lg overflow-hidden">
            <CardHeader className="gradient-primary text-white p-6">
              <CardTitle className="text-2xl font-semibold">Masukkan Data Pribadi Anda</CardTitle>
              <p className="text-blue-100 mt-1">Isi formulir di bawah untuk membuat CV professional</p>
            </CardHeader>

            <CardContent className="p-8">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="nama"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nama Lengkap *</FormLabel>
                          <FormControl>
                            <Input placeholder="Masukkan nama lengkap Anda" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="tgl_lahir"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tanggal Lahir *</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="usia"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Usia *</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="Contoh: 25" 
                              {...field}
                              onChange={(e) => field.onChange(Number(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="jk"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Jenis Kelamin *</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Pilih jenis kelamin" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Pria">Pria</SelectItem>
                              <SelectItem value="Wanita">Wanita</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="alamat@email.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="telepon"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nomor Telepon</FormLabel>
                          <FormControl>
                            <Input type="tel" placeholder="+62 812-3456-7890" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="alamat"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Alamat</FormLabel>
                        <FormControl>
                          <Textarea 
                            rows={2} 
                            placeholder="Masukkan alamat lengkap Anda" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="pendidikan"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Pendidikan Terakhir</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Contoh: S1 Teknik Informatika - Universitas Indonesia" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="keahlian"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Keahlian dan Kompetensi *</FormLabel>
                        <FormControl>
                          <Textarea 
                            rows={6} 
                            placeholder="Tulis semua keahlian dan kompetensi yang Anda miliki. Contoh:&#10;- Pemrograman: Python, JavaScript, PHP&#10;- Desain: Adobe Photoshop, Illustrator&#10;- Bahasa: Indonesia (Native), Inggris (Fluent)&#10;- Manajemen Proyek: Agile, Scrum"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="pengalaman"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Pengalaman Kerja</FormLabel>
                        <FormControl>
                          <Textarea 
                            rows={4} 
                            placeholder="Masukkan pengalaman kerja Anda (opsional). Contoh:&#10;- Software Developer di PT ABC (2020-2023)&#10;- Freelance Web Designer (2018-2020)"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Banner Ad Section */}
                  <div className="ad-section py-4 text-center border-t border-b border-gray-200">
                    <script 
                      type="text/javascript"
                      dangerouslySetInnerHTML={{
                        __html: `
                          atOptions = {
                            'key': '12fb95bb94c88f19b4b95f073cce2fc0',
                            'format': 'iframe',
                            'height': 50,
                            'width': 320,
                            'params': {}
                          };
                        `
                      }}
                    />
                    <script 
                      type="text/javascript" 
                      src="//www.highperformanceformat.com/12fb95bb94c88f19b4b95f073cce2fc0/invoke.js"
                    />
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4 items-center">
                    <div className="flex-1">
                      <FormLabel className="block text-sm font-medium text-gray-700 mb-2">
                        Format Output CV
                      </FormLabel>
                      <Select onValueChange={setSelectedFormat} defaultValue="preview">
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih format" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="preview">Preview di Halaman</SelectItem>
                          <SelectItem value="txt">File TXT</SelectItem>
                          <SelectItem value="html">File HTML</SelectItem>
                          <SelectItem value="pdf">File PDF (HTML Print-Ready)</SelectItem>
                          <SelectItem value="docx">File DOCX</SelectItem>
                          <SelectItem value="png">Gambar PNG</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="bg-secondary hover:bg-blue-600 text-white font-semibold py-4 px-8 h-auto"
                      disabled={downloadMutation.isPending}
                    >
                      <Rocket className="mr-2 h-5 w-5" />
                      {downloadMutation.isPending ? "Memproses..." : "Buatkan CV Otomatis"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* CV Preview */}
          {cvPreview && (
            <Card className="mt-8 bg-white rounded-xl shadow-lg overflow-hidden" id="cvResult">
              <CardHeader className="bg-gray-50 px-6 py-4 border-b">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-xl font-semibold text-gray-800">
                    Preview CV Anda
                  </CardTitle>
                  <div className="flex gap-2 no-print">
                    <Button 
                      onClick={handleDownload}
                      className="bg-green-600 hover:bg-green-700"
                      disabled={downloadMutation.isPending}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      {downloadMutation.isPending ? "Downloading..." : "Download"}
                    </Button>
                    <Button 
                      onClick={handlePrint}
                      variant="outline"
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="p-8">
                <div 
                  id="cvContent" 
                  dangerouslySetInnerHTML={{ __html: cvPreview }}
                />
              </CardContent>
            </Card>
          )}

          {/* Banner Ad Section */}
          <div className="ad-section mt-8 p-4 bg-gray-50 rounded-xl shadow text-center border">
            <div className="text-sm text-gray-500 mb-2">Advertisement</div>
            <div 
              dangerouslySetInnerHTML={{
                __html: `
                  <script async data-cfasync="false" src="//pl27326165.profitableratecpm.com/5e4afa1fb6f5ba69dc7f44cf89eced17/invoke.js"></script>
                  <div id="container-5e4afa1fb6f5ba69dc7f44cf89eced17"></div>
                `
              }}
            />
          </div>

          {/* Native Banner Ad Section */}
          <div className="ad-section mt-8 p-4 bg-gray-50 rounded-xl shadow text-center border">
            <div className="text-sm text-gray-500 mb-2">Sponsored Content</div>
            <div 
              dangerouslySetInnerHTML={{
                __html: `
                  <script async data-cfasync="false" src="//pl27326165.profitableratecpm.com/f4e17df2caf9d1399d4b68ff7a222fd4/invoke.js"></script>
                  <div id="container-f4e17df2caf9d1399d4b68ff7a222fd4"></div>
                `
              }}
            />
          </div>

          {/* Features Section */}
          <div className="mt-12 grid md:grid-cols-3 gap-6">
            <Card className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Rocket className="h-8 w-8 text-secondary" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Cepat & Mudah</h3>
              <p className="text-gray-600">Buat CV professional hanya dalam beberapa menit tanpa registrasi</p>
            </Card>
            
            <Card className="text-center p-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Briefcase className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Template Professional</h3>
              <p className="text-gray-600">Desain CV yang menarik dan sesuai standar perusahaan</p>
            </Card>
            
            <Card className="text-center p-6">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Multi Format</h3>
              <p className="text-gray-600">Download dalam format TXT, PDF, atau gambar PNG</p>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-primary text-white mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-2">BYFORT - CV Builder</h3>
            <p className="text-gray-400 mb-4">Bantu ribuan orang mendapatkan pekerjaan impian mereka</p>
            <div className="flex justify-center space-x-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-white transition duration-200">Tentang Kami</a>
              <a href="#" className="text-gray-400 hover:text-white transition duration-200">Syarat & Ketentuan</a>
              <a href="#" className="text-gray-400 hover:text-white transition duration-200">Kebijakan Privasi</a>
            </div>
            <p className="text-gray-500 text-sm mt-4">&copy; 2025 BYFORT. Semua Hak Dilindungi.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
