# CV Builder Application

## Overview

This is a modern CV builder web application that allows users to create, preview, and download their CVs in multiple formats (TXT, PDF, PNG). Built with a React frontend and Express.js backend, the application provides a user-friendly form interface for inputting personal information, education, skills, and experience, then generates formatted CVs that can be downloaded or previewed in real-time.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Components**: Shadcn/ui component library with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with CSS variables for theming (light/dark mode support)
- **State Management**: React Hook Form for form handling with Zod validation
- **Data Fetching**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Framework**: Express.js with TypeScript (ESM modules)
- **API Design**: RESTful API with structured error handling and request logging
- **PDF Generation**: Puppeteer for server-side PDF generation from HTML
- **File Processing**: Custom text extraction and formatting for multiple export formats
- **Middleware**: Custom logging middleware for API request tracking

### Database Architecture
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Database**: PostgreSQL with Neon serverless driver
- **Schema Management**: Drizzle Kit for migrations and schema changes
- **Storage Pattern**: In-memory storage implementation with interface for easy database integration

### Validation and Type Safety
- **Schema Validation**: Zod schemas shared between frontend and backend
- **Type Generation**: Drizzle-zod for automatic type generation from database schemas
- **Shared Types**: Common type definitions in shared directory for consistency

### Development and Build Pipeline
- **Development**: Hot reload with Vite dev server and TSX for backend development
- **Build Process**: Vite for frontend bundling, ESBuild for backend compilation
- **Type Checking**: TypeScript strict mode with comprehensive type coverage
- **Code Quality**: Integrated with Replit development environment

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL database hosting
- **Connection**: Uses DATABASE_URL environment variable for database connectivity

### Frontend UI Libraries
- **Radix UI**: Comprehensive set of accessible UI primitives (dialogs, forms, navigation, etc.)
- **Shadcn/ui**: Pre-built component library built on top of Radix UI
- **Lucide React**: Icon library for consistent iconography
- **Embla Carousel**: Carousel/slider functionality

### Backend Services
- **Puppeteer**: Headless Chrome automation for PDF generation
- **Express Session**: Session management with PostgreSQL store (connect-pg-simple)

### Development Tools
- **Replit Integration**: Custom Replit plugins for development environment
- **Vite Plugins**: Runtime error overlay and development cartographer
- **PostCSS**: CSS processing with Tailwind CSS and Autoprefixer

### Form and Data Handling
- **React Hook Form**: Performant form library with minimal re-renders
- **Hookform Resolvers**: Integration layer for Zod validation
- **Date-fns**: Date manipulation and formatting utilities
- **Class Variance Authority**: Utility for managing component variants