import { z } from "zod";

export const cvFormSchema = z.object({
  nama: z.string().min(1, "Nama lengkap wajib diisi"),
  tgl_lahir: z.string().min(1, "Tanggal lahir wajib diisi"),
  usia: z.number().min(15, "Usia minimal 15 tahun").max(70, "Usia maksimal 70 tahun"),
  jk: z.enum(["Pria", "Wanita"], { required_error: "Jenis kelamin wajib dipilih" }),
  email: z.string().email("Format email tidak valid").optional().or(z.literal("")),
  telepon: z.string().optional(),
  alamat: z.string().optional(),
  pendidikan: z.string().optional(),
  keahlian: z.string().min(1, "Keahlian wajib diisi"),
  pengalaman: z.string().optional(),
});

export const downloadRequestSchema = z.object({
  format: z.enum(["txt", "html", "pdf", "docx", "png"]),
  data: cvFormSchema,
  content: z.string(),
});

export type CVFormData = z.infer<typeof cvFormSchema>;
export type DownloadRequest = z.infer<typeof downloadRequestSchema>;
